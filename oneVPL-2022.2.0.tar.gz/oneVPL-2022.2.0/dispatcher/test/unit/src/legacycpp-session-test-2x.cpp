/*############################################################################
  # Copyright (C) Intel Corporation
  #
  # SPDX-License-Identifier: MIT
  ############################################################################*/

#ifdef MFXVIDEO_CPP_USE_DEPRECATED
    #undef MFXVIDEO_CPP_USE_DEPRECATED
#endif

#define LEGACY_TEST_VER 2

#include "./legacycpp-session-test.cpp" // NOLINT(build/include)
