/*############################################################################
# Copyright (C) Intel Corporation
#
# SPDX-License-Identifier: MIT
############################################################################*/

//NOLINT(build/header_guard)

#include "src/caps.h"

const mfxDecoderDescription decoderDesc = {
    { 0, 1 },
    {},
    0,
    (DecCodec *)nullptr,
};
