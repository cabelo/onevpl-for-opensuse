/*############################################################################
# Copyright (C) Intel Corporation
#
# SPDX-License-Identifier: MIT
############################################################################*/

//NOLINT(build/header_guard)

#include "src/caps.h"

const mfxVPPDescription vppDesc = {
    { 0, 1 },
    {},
    0,
    (VPPFilter *)nullptr,
};
