The files in this preview folder are provided as a preview of upcoming features.
The content of this folder may be changed or removed without respect for backward compatibility.

For more information on the oneVPL C++ and Python API previews and their examples, see
https://software.intel.com/content/www/us/en/develop/articles/onevpl-preview-examples.html

