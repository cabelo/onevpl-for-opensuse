//==============================================================================
// Copyright Intel Corporation
//
// SPDX-License-Identifier: MIT
//==============================================================================
#include "vpl/preview/future.hpp"
#include "vpl_python.hpp"
namespace vpl = oneapi::vpl;

void init_future(const py::module &m) {}